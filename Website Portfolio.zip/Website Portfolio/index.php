<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edward Policarpio</title>

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/media.css">
    <link rel="stylesheet" href="css/keyframe.css">
    <link rel="icon" href="img/coding.png">
    <script defer src="main.js"></script>


</head>
<body>
    
    <!-- NAVBAR DESKTOP VIEW -->
    <div class="navbar-parent">
        <div class="title-box">
            <a style="font-size: 30px; text-transform: uppercase; font-weight: bold;" href="index.html">Dev Poli</a>
        </div>
        <div class="navbtn-box">
            <button class="navbtn btn-effect" onclick="scrollhome()">
                home
            </button>
            <button class="navbtn btn-effect" onclick="scrollabout()">
                about
            </button>
            <button class="navbtn btn-effect" onclick="scrollskills()">
                skills
            </button>
            <button class="navbtn btn-effect" onclick="scrollprojects()">
                portfolio
            </button>
            <button class="navbtn-contact" onclick="contactme()">
                Contact
            </button>
        </div>
    </div>


    <!-- NAVBAR TABLET/MOBILE VIEW -->
    <div class="menu">
        <div class="title-box1">
            <a style="font-size: 30px; text-transform: uppercase; font-weight: bold;" href="index.html">my portfolio</a>
        </div>
        <div class="menu-box">
            <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
        </div>
    </div>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="#home">Home</a>
        <a href="#about">About</a>
        <a href="#skills">Skills</a>
        <a href="#projects">Portfolio</a>
        <a href="#contact">Contact</a>
      </div>



    <!-- BODY PAGE 1-->
    <section id="home">
        <div class="home-container">
            <div class="intro-parent">
                <div class="intro-box">
                    <h1>Jun Edward Policarpio</h1>
                    <hr>
                    <h2 class="sub-text">aspiring to be software developer</h2><br>
                    <p style="color: #fff;" class="txt">A 3rd year college student currently studying BS Computer Science course with a 92.58% (1.50) GWA.</p><br>
                    <p style="color: #fff;">(+63) 995-487-4557</p>
                    <p style="color: #fff;">(+63) 993-537-2425</p>
                    <br>
                    <a href="files/Resume-Jun-Edward-Policarpio.pdf" target="_blank" class="btn-cv" download="">Dowload CV</a><br><br><br>
                    <div class="socials">
                        <a href="https://www.facebook.com/policarpio30" target="_blank">
                            <img src="img/facebook.png" alt="fb">
                        </a>
                        <a href="https://www.linkedin.com/in/jun-edward-policarpio-89ab77293/" target="_blank">
                            <img src="img/linkedin.png" alt="linkedin">
                        </a>
                        <a href="https://github.com/imapollii" target="_blank">
                            <img src="img/github.png" alt="github">
                        </a>
                        <a href="https://www.instagram.com/p_delatorreedward/" target="_blank">
                            <img src="img/instagram.png" alt="ig">
                        </a>
                        
                    </div>
                </div>
            </div>
            <div class="img-box">
                <div class="img-parent">
                    <div class="circle-parent">
                        <div class="circle green"></div>
                        <div class="circle red"></div>
                        <div class="circle yellow"></div>
                    </div>
                    <img src="img/me.jpg" alt="avatar" class="img">
                </div>
            </div>
        </div>
    </section>

    
    <section id="about">
        <div class="about-container">
            <h2>About Me</h2><br>
            <p style="color: #fff; text-align: justify; text-indent: 5%; font-size: 17px;"> My name is Jun Edward D. Policarpio, 20 years old, 3rd year college student BS Computer Science
                at AISAT College Dasmariñas Cavite, Philippines. Motivated and detail-oriented Computer Science student seeking an internship 
                position in software development to apply and enhance my programming skills, contribute to real-world projects, and gain valuable 
                industry experience.</p><br><br><br><br>
            <h2>Educational Background</h2><br>
            <ul>
                <li>(2021-2025) BS Computer Science - AISAT College Dasmariñas Cavite, Philippines</li><br>
                <li>(2019-2021) TVL-ICT Computer Programming - (Senior High School) PCU Dasmariñas Cavite, Philippines</li><br>
                <li>(2015-2019) ICT Computer Hardware - (Junior High School) Tropical Village National High School Cavite, Philippines</li>
            </ul>
        </div><br>
    </section>
    <section id="skills">
        <div class="skills-container">
            <div class="title-parent">
                <h2 class="skill-title">Here's my skills and IDE's using</h2>
            </div><br>
            <div class="skills-icon-parent">
                <div class="skill-card">
                    <div class="card java">
                        <div class="card__content">
                            <p class="card__title">Java</p>
                            <p class="card__description">It is a fast, secure, reliable programming language for coding everything from mobile apps and enterprise software to big data applications and server-side technologies.</p>
                        </div>
                    </div>

                    <div class="card python">
                        <div class="card__content">
                            <p class="card__title">Python</p>
                            <p class="card__description">Python is often used as a support language for software developers, for build control and management, testing, and in many other ways.</p>
                        </div>
                    </div>

                    <div class="card html">
                        <div class="card__content">
                            <p class="card__title">HTML</p>
                            <p class="card__description">HTML (HyperText Markup Language) is the code that is used to structure a web page and its content.</p>
                        </div>
                    </div>

                    <div class="card css">
                        <div class="card__content">
                            <p class="card__title">CSS</p>
                            <p class="card__description">CSS (Cascading Style Sheets) is the code that is used to style a web page.</p>
                        </div>
                    </div>
                    <div class="card js">
                        <div class="card__content">
                            <p class="card__title">JavaScript</p>
                            <p class="card__description">JavaScript (JS) is a cross-platform, object-oriented programming language used by developers to make web pages interactive.</p>
                        </div>
                    </div>
                    <div class="card vb">
                        <div class="card__content">
                            <p class="card__title">Visual Basic</p>
                            <p class="card__description">Visual Basic is written in Visual Studio and can be used to create executable files that can run independently. </p>
                        </div>
                    </div>
                    <div class="card sql">
                        <div class="card__content">
                            <p class="card__title">SQL</p>
                            <p class="card__description">it is the standard language for relational database management systems. SQL statements are used to perform tasks such as update data on a database, or retrieve data from a database.</p>
                        </div>
                    </div>
                    <div class="card php">
                        <div class="card__content">
                            <p class="card__title">PHP</p>
                            <p class="card__description">PHP is an open-source, server-side programming language that can be used to create websites, applications, customer relationship management systems and more.</p>
                        </div>
                    </div>
                    <div class="card msaccess">
                        <div class="card__content">
                            <p class="card__title">MS Access</p>
                            <p class="card__description">Microsoft Access is a popular information management tool that helps you store all kinds of information for reporting, analysis, and reference.</p>
                        </div>
                    </div>
                    <div class="card excel">
                        <div class="card__content">
                            <p class="card__title">MS Excel</p>
                            <p class="card__description">Microsoft Excel enables users to format, organize and calculate data in a spreadsheet.</p>
                        </div>
                    </div>
                    <div class="card word">
                        <div class="card__content">
                            <p class="card__title">MS Word</p>
                            <p class="card__description">Microsoft Word is a word processing program that allows for the creation of both simple and complex documents.</p>
                        </div>
                    </div>
                    <div class="card ps">
                        <div class="card__content">
                            <p class="card__title">Photoshop</p>
                            <p class="card__description">The software provides many image editing features for pixel-based images, raster graphics and vector graphics.</p>
                        </div>
                    </div>
                    <div class="card vscode">
                        <div class="card__content">
                            <p class="card__title">VS Code</p>
                            <p class="card__description">Visual Studio Code is a streamlined code editor with support for development operations like debugging, task running, and version control.</p>
                        </div>
                    </div>
                    <div class="card vsstudio">
                        <div class="card__content">
                            <p class="card__title">Visual Studio 2022</p>
                            <p class="card__description">Visual Studio is the best IDE to build rich, beautiful, cross platform applications for Windows, Mac, Linux, iOS, and Android.</p>
                        </div>
                    </div>
                    <div class="card netbeans">
                        <div class="card__content">
                            <p class="card__title">Netbeans</p>
                            <p class="card__description">The IDE simplifies the development of web, enterprise, desktop, and mobile applications that use the Java and HTML5 platforms.</p>
                        </div>
                    </div>
            </div>
        </div>
    </section>
    <section id="projects">
        <div class="projects-container">
            <h2 class="project-title">Recent Projects</h2><br>
            <div class="project-card-container">
                <div class="card1">
                    <div class="card-image-container1 cubyertos"></div>
                    <p class="card-title">Resto Management System</p><br>
                    <p class="card-des">
                        A restaurant management system with database for sales reports it also have login UI and invetory system.
                    </p><br>
                    <div class="tags-container">
                        <p class="tags vba">.vb</p>
                        <p class="tags sql1">.sql</p>
                    </div><br>
                    <a href="https://github.com/imapollii/Restaurant-Management-System-with-database" target="_blank" class="download-btn">Download</a>
                </div>

                <div class="card1">
                    <div class="card-image-container1 ordering"></div>
                    <p class="card-title">Simple python ordering system</p><br>
                    <p class="card-des">
                        Console based ordering system application using python programming language.
                    </p><br>
                    <div class="tags-container">
                        <p class="tags python1">.py</p>
                    </div><br>
                    <a href="https://github.com/imapollii/Simple-Food-Ordering-System-Python" target="_blank" class="download-btn">Download</a>
                </div>

                <div class="card1">
                    <div class="card-image-container1 website"></div>
                    <p class="card-title">Website Portfolio</p><br>
                    <p class="card-des">
                        A responsive website portfolio using HTML, CSS, Javascript, Media query, PHP, MyPHPAdmin.
                    </p><br>
                    <div class="tags-container">
                        <p class="tags html1">.html</p>
                        <p class="tags css1">.css</p>
                        <p class="tags js1">.js</p>
                        <p class="tags php1">.php</p>
                    </div><br>
                    <a href="#" target="_blank" class="download-btn">Download</a>
                </div>

            </div>
        </div>
    </section>
    <section id="contact">
        <div class="contact-container">
            <div class="contact-parent">
                <div class="col-lg-6 m-auto">
                    <div class="card2 mt-5">
                        <div class="card-title1">
                            <h2 class="ctitle"> Contact Us </h2>
                            <hr class="hrcontact">
                            <?php 
                                $Msg = "";
                                if(isset($_GET['error']))
                                {
                                    $Msg = " Please Fill in the Blanks ";
                                    echo '<div class="alert alert-danger">'.$Msg.'</div>';
                                }

                                if(isset($_GET['success']))
                                {
                                    $Msg = " Your Message Has Been Sent ";
                                    echo '<div class="alert alert-success">'.$Msg.'</div>';
                                }
                            
                            ?>
                        </div>
                        <div class="contact-body"><br>
                            <form action="process.php" method="post">
                                <input type="email" name="Email" placeholder="Email" class="txtinput">
                                <input type="text" name="Subject" placeholder="Subject" class="txtinput">
                                <textarea name="msg" class="txtinput textarea1" placeholder="Write The Message"></textarea><br><br>
                                <button class="btn btn-success" name="btn-send"> Send </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="footer">
        <p style="color: #505050; font-size: 13px;">© All rights reserved 2024, Jun Edward Policarpio</p>
    </div>
</body>
</html>