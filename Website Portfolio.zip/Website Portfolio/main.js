// NAVBAR FUNCTION 
function scrollhome(){
    var elem = document.getElementById("home");
    elem.scrollIntoView();
}
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }

  function scrollabout(){
    var elem = document.getElementById("about");
    elem.scrollIntoView();
}
function scrollskills(){
  var elem = document.getElementById("skills");
  elem.scrollIntoView();
}
function scrollprojects(){
  var elem = document.getElementById("projects");
  elem.scrollIntoView();
}
function contactme(){
  var elem = document.getElementById("contact");
  elem.scrollIntoView();
}